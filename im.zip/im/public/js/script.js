$(function() {
    $('#delete').click(function(e){
        e.preventDefault();
        ('#delete-form').submit();
    });
  });