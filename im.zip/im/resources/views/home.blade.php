@extends('layouts.home')
@section('title','Dashboard')
@section('content')
    <p>Selamat Datang</p>
@endsection
