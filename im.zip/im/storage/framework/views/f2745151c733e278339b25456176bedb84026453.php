<?php $__env->startSection('title','User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-bottom:5px;">
        <a href="/user/create" class="btn btn-xs btn-primary"> <i class="glyphicon glyphicon-plus"></i> New </a>
    </div>
    <div class="row">
        <table class="table">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th></th>
            </tr>
            
            <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <ul class="list-inline">
                        <li><a href="/user/<?php echo e($user->id); ?>/edit" class="btn btn-xs btn-warning"> <i class="glyphicon glyphicon-edit"></i>  Edit</a></li>
                        <li>
                                <form action="/user/<?php echo e($user->id); ?>" method="POST" id="delete-form">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-danger"> <i class="glyphicon glyphicon-trash"></i> Delete</button>
                                </form>
                        </li>
                    </ul>      
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>