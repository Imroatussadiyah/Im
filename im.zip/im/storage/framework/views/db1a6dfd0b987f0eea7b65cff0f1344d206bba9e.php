<?php $__env->startSection('title','Edit Artikel'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <form class="form-horizontal" action="/artikel/<?php echo e($artikel->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="col-sm-6">
                    <input type="text" name="judul" class="form-control" id="judul" placeholder="Judul Artikel" value="<?php echo e($artikel->judul); ?>">
                    </div>
                    <div class="col-sm-6">
                        <select name="kategori" id="kategori" class="form-control">
                            <?php $__currentLoopData = $data_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(($artikel->kategori_id==$kategori->id ? 'selected' : '')); ?> value="<?php echo e($kategori->id); ?>"> <?php echo e($kategori->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <textarea name="isi" id="isi" cols="100" rows="10"><?php echo e($artikel->isi); ?></textarea>
                    </div>
                       <div class="form-group">
                    <label for="gambar" class="control-label col-sm-2">Gambar</label>
                    <div class="col-sm-8">
                        <img src="<?php echo e(asset('images/'.$artikel->gambar)); ?>" alt="<?php echo e($artikel->judul); ?>" width="300px">
                        <input type="file" class="form-group" name="gambar">
                    </div>
                </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-10 ">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
            </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>