<?php $__env->startSection('title','Artikel'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-bottom:5px;">
        <a href="/artikel/create" class="btn btn-xs btn-primary"> <i class="glyphicon glyphicon-plus"></i> New </a>
    </div>
    <div class="row">
        <table class="table">
            <tr>
                <th>#</th>
                <th>Judul</th>
                <th>Kategori</th>
                <th>Penulis</th>
                <th></th>
            </tr>
            
            <?php $__currentLoopData = $data_artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($artikel->id); ?></td>
                <td><?php echo e($artikel->judul); ?></td>
                <td><?php echo e($artikel->kategori->nama); ?></td>
                <td><?php echo e($artikel->user->name); ?></td>
                <td>
                    <ul class="list-inline">
                        <li><a href="/artikel/<?php echo e($artikel->id); ?>/edit" class="btn btn-xs btn-warning"> <i class="glyphicon glyphicon-edit"></i>  Edit</a></li>
                        <li>
                                <form action="/artikel/<?php echo e($artikel->id); ?>" method="POST" id="delete-form">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-xs btn-danger"> <i class="glyphicon glyphicon-trash"></i> Delete</button>
                                </form>
                        </li>
                    </ul>      
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>